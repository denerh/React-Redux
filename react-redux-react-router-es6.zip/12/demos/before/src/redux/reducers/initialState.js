export default {
  courses: [],
  authors: []
};
